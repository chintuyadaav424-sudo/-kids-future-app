# Kids Future — production security checklist

- Never send an AI provider secret key to the browser.
- Never store real passwords in localStorage.
- Use secure authentication, password hashing and session management.
- Verify parent/guardian consent before collecting child data.
- Minimize child data and define retention/deletion controls.
- Add server-side AI moderation and age-appropriate response rules.
- Do not allow the tutor to request or expose sensitive personal data.
- Verify payment webhooks/receipts on the server.
- Add rate limits, logging, abuse monitoring and backups.
- Complete applicable child-privacy and app-store compliance review before launch.
