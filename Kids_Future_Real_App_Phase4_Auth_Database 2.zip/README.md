# Kids Future — Real App Starter

The V40 prototype is packaged as an installable PWA starter.

## Added in the next engineering phase
- `backend/server.js` — server-side API contract/stub for AI Tutor, auth and subscriptions
- `backend/schema.sql` — PostgreSQL data model starter
- `backend/.env.example` — secret configuration template
- `PRODUCTION_SECURITY.md` — security and child-safety launch checklist

## Current status
The backend endpoints intentionally return a clear “not connected” response. No fake AI, fake login, or fake payment is presented as real.

## To become production-ready
Connect a secure auth service/database, a server-side AI provider with moderation, and a real subscription provider. Then test parental consent, privacy, security, app-store rules and child-safety requirements before launch.
