# Real AI Tutor Integration

## What is ready
- Browser sends questions to `/api/tutor`
- AI provider key remains server-side
- Age group and topic are part of the tutor request
- Basic privacy/safety rules and input sanitization are defined
- Provider adapter is isolated in `backend/ai-tutor.js`

## What remains
1. Choose an AI provider and create a server-side API key.
2. Implement `callProvider()` in `backend/ai-tutor.js`.
3. Add authentication and verify parent/guardian consent before tutor access.
4. Add server-side input/output moderation and abuse/rate limits.
5. Test separately for ages 5–7, 8–10 and 11–14.
6. Store only the minimum progress data needed.

No API key is included in this package.
