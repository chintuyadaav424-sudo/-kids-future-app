# Parent Login + Cloud Database — Phase 4

## Added
- Server-side password hashing contract using Node `scrypt`
- Parent registration validation
- Login endpoint contract
- PostgreSQL credential table and indexes
- Parent → children → progress data model
- Explicit secure-session requirements

## Production requirements
- Prefer a managed, audited authentication provider where practical.
- Store password hashes only; never store plain-text passwords.
- Use secure, httpOnly, SameSite session cookies.
- Add email verification, password reset and rate limiting.
- Require verified parent/guardian consent before child data is stored.
- Apply least-privilege database access and backups.
- Add account deletion/data-export flows where required.

No real credentials are included.
