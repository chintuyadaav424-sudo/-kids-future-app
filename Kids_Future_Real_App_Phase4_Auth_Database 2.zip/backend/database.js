// Kids Future — database access contract
// Replace these functions with your PostgreSQL client/ORM.

async function createParent({ id, email, displayName, passwordHash, passwordSalt }) {
  // INSERT INTO parents + credentials table in production.
  return { id, email, displayName, passwordHash, passwordSalt };
}

async function createChild({ id, parentId, displayName, ageGroup }) {
  // INSERT INTO children in production.
  return { id, parentId, displayName, ageGroup };
}

async function getChildren(parentId) {
  // SELECT children WHERE parent_id = $1 in production.
  return [];
}

async function saveProgress({ childId, xp, coins, streak, lessonsCompleted }) {
  // UPSERT progress in production.
  return { childId, xp, coins, streak, lessonsCompleted };
}

module.exports = { createParent, createChild, getChildren, saveProgress };
