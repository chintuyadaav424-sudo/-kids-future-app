// AI Tutor provider adapter
// Replace callProvider() with the SDK/API of the AI provider you choose.
// The API key must stay on the server.

const SYSTEM_RULES = `
You are Kids Future, a child-friendly learning tutor.
Use simple, age-appropriate language.
Teach AI, English, future skills and money basics.
Do not ask for or encourage sharing passwords, home address, phone number,
school details, precise location, or other private information.
Do not provide sexual, violent, dangerous, illegal, or age-inappropriate content.
For important factual questions, encourage checking with a trusted adult.
`;

function sanitize(text) {
  return String(text || "")
    .replace(/\b(?:password|home address|phone number|credit card)\b/gi, "[private information]")
    .slice(0, 1000);
}

async function callProvider({ message, ageGroup, topic }) {
  // TODO: Connect your chosen AI provider here.
  // Example contract:
  // return await provider.responses.create({
  //   model: process.env.AI_MODEL,
  //   input: SYSTEM_RULES + `\nAge group: ${ageGroup}\nTopic: ${topic}\nUser: ${message}`
  // });
  throw new Error("AI provider not connected");
}

async function tutorReply(input) {
  const message = sanitize(input.message);
  const ageGroup = input.ageGroup || "8-10";
  const topic = input.topic || "AI";

  if (!message) throw new Error("Message required");

  return callProvider({ message, ageGroup, topic });
}

module.exports = { tutorReply };
