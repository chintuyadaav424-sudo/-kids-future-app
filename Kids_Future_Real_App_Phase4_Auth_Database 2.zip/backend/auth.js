// Kids Future — secure parent auth contract
// Demo/starter only. Use a managed auth service or audited auth library in production.

const crypto = require("crypto");

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { hash, salt };
}

function verifyPassword(password, hash, salt) {
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(derived, "hex"), Buffer.from(hash, "hex"));
}

function validateParentInput({ email, password, displayName }) {
  if (!email || !email.includes("@")) throw new Error("Valid parent email required");
  if (!password || password.length < 10) throw new Error("Use a stronger password");
  if (!displayName || displayName.trim().length < 2) throw new Error("Parent name required");
  return true;
}

module.exports = { hashPassword, verifyPassword, validateParentInput };
