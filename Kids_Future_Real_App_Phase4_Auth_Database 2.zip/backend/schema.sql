-- Kids Future production data model starter
-- Use a managed PostgreSQL database in production.

CREATE TABLE parents (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE children (
  id UUID PRIMARY KEY,
  parent_id UUID NOT NULL REFERENCES parents(id),
  display_name TEXT NOT NULL,
  age_group TEXT NOT NULL CHECK (age_group IN ('5-7','8-10','11-14')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE progress (
  child_id UUID PRIMARY KEY REFERENCES children(id),
  xp INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  lessons_completed INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  parent_id UUID NOT NULL REFERENCES parents(id),
  plan TEXT NOT NULL CHECK (plan IN ('monthly','yearly')),
  provider_customer_id TEXT,
  provider_subscription_id TEXT,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


CREATE TABLE parent_credentials (
  parent_id UUID PRIMARY KEY REFERENCES parents(id),
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_children_parent_id ON children(parent_id);
CREATE INDEX idx_subscriptions_parent_id ON subscriptions(parent_id);
