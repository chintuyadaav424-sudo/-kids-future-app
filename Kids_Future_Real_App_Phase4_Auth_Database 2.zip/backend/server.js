// Kids Future — production backend starter
// This is a contract/stub, not a live public server.
// Put real provider SDK calls behind these endpoints.

const http = require("http");
const { tutorReply } = require('./ai-tutor');
const { hashPassword, validateParentInput } = require('./auth');

function json(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return json(res, 204, {});
  if (req.url === "/health") return json(res, 200, { ok: true, app: "kids-future" });

  if (req.method === "POST" && req.url === "/api/tutor") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", async () => {
      try {
        const input = JSON.parse(body || "{}");
        // Production: verify authenticated parent/child session and consent here.
        const reply = await tutorReply(input);
        return json(res, 200, { ok: true, reply });
      } catch (err) {
        return json(res, 501, {
          error: err.message,
          next: "Connect the provider adapter and enable server-side moderation."
        });
      }
    });
    return;
  }

  if (req.method === "POST" && req.url === "/api/auth/register") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", async () => {
      try {
        const input = JSON.parse(body || "{}");
        validateParentInput(input);
        const credentials = hashPassword(input.password);
        // Production: persist parent + credentials in PostgreSQL,
        // then issue a secure, httpOnly session cookie.
        return json(res, 501, {
          error: "Database/session provider not connected",
          next: "Persist the parent securely and issue an httpOnly session.",
          passwordHashCreated: Boolean(credentials.hash)
        });
      } catch (err) {
        return json(res, 400, { error: err.message });
      }
    });
    return;
  }

  if (req.method === "POST" && req.url === "/api/auth/login") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", async () => {
      // Production: fetch credential record by email, verify password,
      // rotate session, and set an httpOnly + Secure + SameSite cookie.
      return json(res, 501, {
        error: "Auth database/session provider not connected",
        next: "Connect credential storage and secure session management."
      });
    });
    return;
  }

  if (req.method === "POST" && req.url === "/api/subscription/checkout") {
    return json(res, 501, {
      error: "Payment provider not connected",
      next: "Create checkout server-side and verify webhooks/receipts."
    });
  }

  return json(res, 404, { error: "Not found" });
});

server.listen(process.env.PORT || 3000, () =>
  console.log("Kids Future backend starter listening")
);
