// Browser-side helper: talks only to your own backend.
async function askKidsFutureTutor(message, ageGroup, topic) {
  const response = await fetch("/api/tutor", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({message, ageGroup, topic})
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Tutor unavailable");
  return data.reply;
}
